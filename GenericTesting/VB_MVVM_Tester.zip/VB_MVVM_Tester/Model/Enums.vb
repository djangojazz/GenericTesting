﻿
Public Enum ShipType
    Owned = 1
    Contractor = 2
    Other = 3
  End Enum


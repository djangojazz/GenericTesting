﻿Public Class Stuff
  Public Property Id As Integer
  Public Property Value As String
  Public Property ShipType As ShipType
  Public Property MoreStuff As String
End Class

﻿Public Class POCO
  Public Property Id As Integer
  Public Property Desc As String
  Public Property DescAction As Action(Of String)
  'ProducerConsumerFinished
End Class
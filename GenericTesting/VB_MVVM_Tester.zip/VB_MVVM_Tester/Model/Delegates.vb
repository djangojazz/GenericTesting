﻿Public Delegate Sub ProducerConsumerFinished(result As String)


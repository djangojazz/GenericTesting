﻿Public Class CustomMarqueeControl

End Class
